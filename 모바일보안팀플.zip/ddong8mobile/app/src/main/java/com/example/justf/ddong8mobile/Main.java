package com.example.justf.ddong8mobile;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class Main extends AppCompatActivity {
    // public class LoginDemoClient1Activity extends Activity implements
    // 		OnClickListener {


    private final String TAG = "LoginDemo1";
    private HttpResponse response;
    // private Login login;

    /** Called when the activity is first created. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button button = (Button) findViewById(R.id.login);

        OnClickListener sendlistener = new OnClickListener() {
            @Override
            public void onClick(View view) {
                SendPost sendPostTask = new SendPost();
                sendPostTask.execute();
                // String username = ((EditText) findViewById(R.id.username)).getText().toString();
                // String password = ((EditText) findViewById(R.id.password)).getText().toString();
                // Log.i(TAG, "username0 = " + username);
                // Log.i(TAG, "password0 = " + password);
            }
        };
        button.setOnClickListener(sendlistener);

    }

    private class SendPost extends AsyncTask<Void, Void, String> {
        String msg = "";

        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            // 모두 작업을 마치고 실행할 일 (메소드 등등)
            EditText text = (EditText) findViewById(R.id.editText1);
            text.setText(msg);
        }

        // 실제 전송하는 부분
        public String executeClient() {

            Log.i(TAG, "Execute executeClient()");
            HttpClient client = new DefaultHttpClient();

            // HttpPost post = new HttpPost("http://logindemo1.appspot.com/logindemo");
            // HttpPost post = new HttpPost("http://210.93.60.86/login");
            HttpPost post = new HttpPost("http://192.168.35.247:3000/login");

            HttpResponse response = null;

            // post 데이터 설정을 통한 매개 변수 전달
            String username = ((EditText) findViewById(R.id.username)).getText().toString();
            String password = ((EditText) findViewById(R.id.password)).getText(). toString();

            // Log.i(TAG, "username1 = " + username);
            // Log.i(TAG, "password1 = " + password);

            List<NameValuePair> nvPairs = new ArrayList<NameValuePair>(2);
            nvPairs.add(new BasicNameValuePair("username", username));
            nvPairs.add(new BasicNameValuePair("password", password));

            try {
                UrlEncodedFormEntity params = new UrlEncodedFormEntity(nvPairs);
                post.setEntity(params);
                response = client.execute(post);
                Log.i(TAG, "After client.execute()");
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Unsupported Encoding used");
            } catch (ClientProtocolException e) {
                Log.e(TAG, "Client Protocol Exception");
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            }

            if (response != null) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(response.getEntity()
                                        .getContent()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        msg = sb.toString();
                        if(msg.equals("<h1>Login success!!</h1>")){
                            Intent intent = new Intent(Main.this , Data.class);
                            startActivity(intent);
                        }
                    } catch (IOException e) {
                        Log.e(TAG, "IO Exception in reading from stream.");
                    }
                } else {
                    msg = "Status code other than HTTP 200 received";
                }
            } else {
                msg = "Response is null";
            }
            Log.i(TAG, "msg = " + msg);
            return msg;
        }
    }
}