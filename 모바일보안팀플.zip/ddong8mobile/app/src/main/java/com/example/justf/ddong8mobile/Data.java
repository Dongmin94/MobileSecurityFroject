package com.example.justf.ddong8mobile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Data extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data);
    }
}
