// 모듈을 추출합니다.
var fs = require('fs');
var ejs = require('ejs');
var mysql = require('mysql');
var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');

// 데이터베이스와 연결합니다.
var conn = mysql.createConnection({
  host     : '127.0.0.1',
  user     : 'root',
  password : '111111',
  database : 'mobile'
});

conn.connect();

//서버 생성
var app = express();
app.set('port', process.env.PORT || 3000);


var sql = 'SELECT * FROM bankinfo';



app.get('/', function(req,res){
    res.send('Root');
});



// 미들웨어를 설정합니다.
//시용자 아이디와 비번 추출.
app.use(bodyParser.urlencoded({ extended:false}));

app.post('/login', function(request, response) {

    // 쿠키를 생성합니다.
    var username = request.body.username;
    var password = request.body.password;

    // 출력합니다.
    console.log(username, password);
    console.log(request.body);

    // 로그인을 확인합니다.
    if(username == 'aaaa' && password == 'bbbb') {
        // 로그인 성공
        response.send('<h1>Login success!!</h1>');
    } else {
        // 로그인 실패
        response.send('<h1>Login failed!!</h1>');
    }
});

//DB내용 출력
app.get('/mysql', function(req, res){
        conn.query(sql,function(err,rows){
        if(err) throw err;

        console.log(rows);
        res.send(rows);
        
    });
});

// 서버를 실행합니다.
app.listen(app.get('port'), function() {
    console.log('server is running at http 192.168.35.247:' + app.get('port'));
});

/*
// 라우트를 수행합니다.
app.get('/mysql', function(request, response) {
    // 파일을 읽습니다.
    fs.readFile('list1.html', 'utf8', function(error, data) {
         // 데이터베이스 쿼리를 실행합니다.
        client.query('SELECT * FROM bankinfo', function(error, results) {
             // 응답합니다.
            response.send(ejs.render(data, {
                data : results
            }));
        });
    });
});*/

/*// 서버를 생성합니다.
var app = express();






*/