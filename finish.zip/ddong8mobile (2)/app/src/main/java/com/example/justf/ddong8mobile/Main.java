package com.example.justf.ddong8mobile;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class Main extends AppCompatActivity {
    // public class LoginDemoClient1Activity extends Activity implements
    // 		OnClickListener {

    private final String TAG = "LoginDemo1";
    private HttpResponse response;
    // private Login login;

    /** Called when the activity is first created. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button button = (Button) findViewById(R.id.login);

        OnClickListener sendlistener = new OnClickListener() {
            @Override
            public void onClick(View view) {
                SendPost sendPostTask = new SendPost();
                sendPostTask.execute();
                // String username = ((EditText) findViewById(R.id.username)).getText().toString();
                // String password = ((EditText) findViewById(R.id.password)).getText().toString();
                // Log.i(TAG, "username0 = " + username);
                // Log.i(TAG, "password0 = " + password);
            }
        };
        button.setOnClickListener(sendlistener);

    }

    //취소버튼이 눌리면 입력했던값들을 지움
    public void btn_cancle (View v) {
        Toast.makeText(Main.this, "cancel", Toast.LENGTH_SHORT).show();
        final EditText idtext = (EditText)findViewById(R.id.username);
        final EditText pwtext = (EditText)findViewById(R.id.password);
        idtext.setText("");
        pwtext.setText("");

    }

    private class SendPost extends AsyncTask<Void, Void, String> {
        String msg = "";

        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            // 모두 작업을 마치고 실행할 일 (메소드 등등)
            EditText text = (EditText) findViewById(R.id.editText1);
            text.setText(msg);
        }

        // 실제 전송하는 부분
        public String executeClient() {

            Log.i(TAG, "Execute executeClient()");
            HttpClient client = new DefaultHttpClient();

            // HttpPost post = new HttpPost("http://logindemo1.appspot.com/logindemo");
            // HttpPost post = new HttpPost("http://210.93.60.86/login");
            HttpPost post = new HttpPost("http://192.168.10.100/login");

            HttpResponse response = null;

            // post 데이터 설정을 통한 매개 변수 전달
            String username = ((EditText) findViewById(R.id.username)).getText().toString();
            String pass = ((EditText) findViewById(R.id.password)).getText(). toString();

            // Log.i(TAG, "username1 = " + username);
            // Log.i(TAG, "password1 = " + password);


            //해시암호화

            String algo = "HmacSHA1";
            String message = "sha1testing";
            byte[] messageBytes = message.getBytes();
            SecretKeySpec key = new SecretKeySpec(pass.getBytes(), algo);
            Mac mac = null;
            try {
                mac = Mac.getInstance(algo);
            } catch (NoSuchAlgorithmException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            try {
                mac.init(key);
            } catch (InvalidKeyException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


            byte[] preResponse = mac.doFinal(messageBytes);

            String password =toHex(preResponse).toString();

            //

            List<NameValuePair> nvPairs = new ArrayList<NameValuePair>(2);
            nvPairs.add(new BasicNameValuePair("username", username));
            nvPairs.add(new BasicNameValuePair("password", password));

            try {
                UrlEncodedFormEntity params = new UrlEncodedFormEntity(nvPairs);
                post.setEntity(params);
                response = client.execute(post);
                Log.i(TAG, "After client.execute()");
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Unsupported Encoding used");
            } catch (ClientProtocolException e) {
                Log.e(TAG, "Client Protocol Exception");
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            }

            if (response != null) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(response.getEntity()
                                        .getContent()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        msg = sb.toString();
                        if(msg.equals("<h1>로그인 성공</h1>")){
                            Intent intent = new Intent(Main.this , Data.class);
                            startActivity(intent);
                        }
                    } catch (IOException e) {
                        Log.e(TAG, "IO Exception in reading from stream.");
                    }
                } else {
                    msg = "Status code other than HTTP 200 received";
                }
            } else {
                msg = "Response is null";
            }
            Log.i(TAG, "msg = " + msg);
            return msg;
        }
    }

    String toHex(byte[] dataByte) {
        StringBuffer sb = new StringBuffer(dataByte.length * 2);
        String hexCode;
        for (int x = 0; x < dataByte.length; x++) {
            hexCode = "0" + Integer.toHexString(0xff & dataByte[x]);
            sb.append(hexCode.substring(hexCode.length() - 2));
        }
        return sb.toString();
    }
}