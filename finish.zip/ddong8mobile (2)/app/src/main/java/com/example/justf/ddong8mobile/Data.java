package com.example.justf.ddong8mobile;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.drm.DrmStore;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Data extends Activity {
    EditText editText1;
    EditText editText2;
    String keyStr = "MTIzNDU2Nzg5MDEy";
    String ivStr = "mTIzNDU2Nzg5MDEy";
    byte [] keyBytes = keyStr.getBytes();
    byte [] ivBytes = ivStr.getBytes();
    private final String TAG = "Tasking";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data);

        Button btn1 = (Button) findViewById(R.id.button_call);
        Button btn2 = (Button) findViewById(R.id.button_read);
        Button btn3 = (Button) findViewById(R.id.button_input);
        Button btn4 = (Button) findViewById(R.id.button_output);
        Button btn5 = (Button) findViewById(R.id.button_make);
        Button btn6 = (Button) findViewById(R.id.exit);



        editText1 = (EditText) findViewById(R.id.inserting1);
        editText2 = (EditText) findViewById(R.id.inserting2);
    }
    //1번 버튼 내용
    public void onClick(View v) {
        DownloadTask downloadTask = new DownloadTask();
        WebView web_response = (WebView) findViewById(R.id.webpage_src);
        String sqlSelectResult = null;
        web_response.getSettings().setJavaScriptEnabled(true);

        try {
            sqlSelectResult = downloadTask.execute("http://192.168.10.100/my").get().toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (sqlSelectResult == null) {
            Log.v("REST-SQL", "Exception while downloading sqlSelectResult= " + sqlSelectResult);
            return;
        }

        Log.v("REST-SQL", "sqlSelectResult= " + sqlSelectResult);
        web_response.loadData(sqlSelectResult, "text/html", "UTF-8");
        Toast.makeText(Data.this, "JSON파싱", Toast.LENGTH_SHORT).show();

    }


    //2번 버튼 내용
    public void bank_ok(View v) {
        SendPost sendPostTask = new SendPost();
        sendPostTask.execute();
        Toast.makeText(Data.this, "JSON파싱", Toast.LENGTH_SHORT).show();
    }


        //3번 버튼 내용
    public void bank_mk(View v) {
        BankMk sendPostTask = new BankMk();
        sendPostTask.execute();
    }

    //4번 버튼 내용
    public void bank_ip(View v) {
        BankIn sendPostTask = new BankIn();
        sendPostTask.execute();
    }

    //5번 버튼 내용
    public void bank_op(View v) {
        BankOu sendPostTask = new BankOu();
        sendPostTask.execute();
    }


    //종료 버튼 내용
    public void onExit(View v) {
        Exitu sendPostTask = new Exitu();
        sendPostTask.execute();
    }






    private StringBuffer downloadUrl(String strUrl) throws IOException{
        StringBuffer sb = null;
        InputStream iStream = null;
        BufferedReader in = null;

        try {
            URL url = new URL(strUrl);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            in = new BufferedReader(new InputStreamReader(iStream));

            sb = new StringBuffer("");
            String line = "";

            while ((line = in.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            Log.v("REST-SQL", "Exception while downloading url= " + sb);
            e.printStackTrace();
        }finally {
            iStream.close();
        }
        return sb;
    }


    private class DownloadTask extends AsyncTask<String, Void, StringBuffer> {
            StringBuffer s = null;

            @Override
            protected StringBuffer doInBackground(String... url) {
                try {
                    s = downloadUrl(url[0]);
                } catch (Exception e) {
                    Log.v("REST-SQL", "Background Task");
                }
                return s;
            }

        @Override
        protected void onPostExecute(StringBuffer stringBuffer) {

        }
    }



    private class SendPost extends AsyncTask<Void, Void, String> {
        String msg = "";

        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            WebView web_response = (WebView) findViewById(R.id.webpage_src);
            web_response.getSettings().setJavaScriptEnabled(true);

            web_response.loadData(msg, "text/html", "UTF-8");
        }

        // 실제 전송하는 부분
        public String executeClient() {

            Log.i(TAG, "Execute executeClient()");
            HttpClient client = new DefaultHttpClient();

            // HttpPost post = new HttpPost("http://logindemo1.appspot.com/logindemo");
            // HttpPost post = new HttpPost("http://210.93.60.86/login");
            HttpPost post = new HttpPost("http://192.168.10.100/ok");

            HttpResponse response = null;

            // post 데이터 설정을 통한 매개 변수 전달
            String msg1 = editText1.getText().toString();

            List<NameValuePair> nvPairs = new ArrayList<NameValuePair>(1);
            try {
                Charset charset = Charset.forName("UTF-8");
                // 암호화
                SecretKeySpec sks = new SecretKeySpec(keyBytes, "AES");
                IvParameterSpec iv = new IvParameterSpec(ivBytes);
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
                cipher.init(Cipher.ENCRYPT_MODE, sks, iv);
                byte[] encryptedData1 = cipher.doFinal(msg1.getBytes(charset));

                nvPairs.add(new BasicNameValuePair("msg1", Base64.getEncoder().encodeToString(encryptedData1)));

                UrlEncodedFormEntity params = new UrlEncodedFormEntity(nvPairs);
                post.setEntity(params);
                response = client.execute(post);
                Log.i(TAG, "After client.execute()");
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Unsupported Encoding used");
            } catch (ClientProtocolException e) {
                Log.e(TAG, "Client Protocol Exception");
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            }catch (Exception e){

            }

            if (response != null) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(response.getEntity()
                                        .getContent()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        String kas=sb.toString();
                        byte[] has =kas.getBytes();
                        Charset charset = Charset.forName("UTF-8");

                        SecretKeySpec sks = new SecretKeySpec(keyBytes, "AES");
                        IvParameterSpec iv = new IvParameterSpec(ivBytes);
                        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
                        cipher.init(Cipher.DECRYPT_MODE, sks, iv);
                        byte[] plainData = Base64.getDecoder().decode(kas);

                        msg=new String(cipher.doFinal(plainData),"UTF-8");



                    } catch (IOException e) {
                        Log.e(TAG, "IO Exception in reading from stream.");
                    }catch(Exception e){
                    }
                } else {
                    msg = "Status code other than HTTP 200 received";
                }
            } else {
                msg = "Response is null";
            }
            Log.i(TAG, "msg = " + msg);
            return msg;
        }
    }


    private class BankMk extends AsyncTask<Void, Void, String> {
        String msg = "";

        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            Toast.makeText(Data.this, "생성 되었습니다.", Toast.LENGTH_SHORT).show();
        }

        // 실제 전송하는 부분
        public String executeClient() {

            Log.i(TAG, "Execute executeClient()");
            HttpClient client = new DefaultHttpClient();

            // HttpPost post = new HttpPost("http://logindemo1.appspot.com/logindemo");
            // HttpPost post = new HttpPost("http://210.93.60.86/login");
            HttpPost post = new HttpPost("http://192.168.10.100/mk");

            HttpResponse response = null;

            // post 데이터 설정을 통한 매개 변수 전달
            String msg1 = editText1.getText().toString();
            String msg2 = editText2.getText().toString();
            List<NameValuePair> nvPairs = new ArrayList<NameValuePair>(2);
            try {
                Charset charset = Charset.forName("UTF-8");
                // 암호화
                SecretKeySpec sks = new SecretKeySpec(keyBytes, "AES");
                IvParameterSpec iv = new IvParameterSpec(ivBytes);
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
                cipher.init(Cipher.ENCRYPT_MODE, sks, iv);
                byte[] encryptedData1 = cipher.doFinal(msg1.getBytes(charset));
                byte[] encryptedData2= cipher.doFinal(msg2.getBytes(charset));
                // System.out.println("암호문: " + bytesToHex(encryptedData));
                //String mssg1= Base64.getEncoder().encodeToString(encryptedData1);

                nvPairs.add(new BasicNameValuePair("msg1", Base64.getEncoder().encodeToString(encryptedData1)));
                nvPairs.add(new BasicNameValuePair("msg2",Base64.getEncoder().encodeToString(encryptedData2)));


                UrlEncodedFormEntity params = new UrlEncodedFormEntity(nvPairs);
                post.setEntity(params);
                response = client.execute(post);
                Log.i(TAG, "After client.execute()");
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Unsupported Encoding used");
            } catch (ClientProtocolException e) {
                Log.e(TAG, "Client Protocol Exception");
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            } catch (Exception e) {
                e.printStackTrace();
            }


            if (response != null) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(response.getEntity()
                                        .getContent()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        msg = sb.toString();
                    } catch (IOException e) {
                        Log.e(TAG, "IO Exception in reading from stream.");
                    }
                } else {
                    msg = "Status code other than HTTP 200 received";
                }
            } else {
                msg = "Response is null";
            }
            Log.i(TAG, "msg = " + msg);
            return msg;
        }
    }


    private class BankIn extends AsyncTask<Void, Void, String> {
        String msg = "";

        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            Toast.makeText(Data.this, "입금 되었습니다.", Toast.LENGTH_SHORT).show();
        }

        // 실제 전송하는 부분
        public String executeClient() {

            Log.i(TAG, "Execute executeClient()");
            HttpClient client = new DefaultHttpClient();

            // HttpPost post = new HttpPost("http://logindemo1.appspot.com/logindemo");
            // HttpPost post = new HttpPost("http://210.93.60.86/login");
            HttpPost post = new HttpPost("http://192.168.10.100/in");

            HttpResponse response = null;

            // post 데이터 설정을 통한 매개 변수 전달
            String msg1 = editText1.getText().toString();
            String msg2 = editText2.getText().toString();
            List<NameValuePair> nvPairs = new ArrayList<NameValuePair>(2);
            try {
                Charset charset = Charset.forName("UTF-8");
                // 암호화
                SecretKeySpec sks = new SecretKeySpec(keyBytes, "AES");
                IvParameterSpec iv = new IvParameterSpec(ivBytes);
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
                cipher.init(Cipher.ENCRYPT_MODE, sks, iv);
                byte[] encryptedData1 = cipher.doFinal(msg1.getBytes(charset));
                byte[] encryptedData2= cipher.doFinal(msg2.getBytes(charset));
                // System.out.println("암호문: " + bytesToHex(encryptedData));
                //String mssg1= Base64.getEncoder().encodeToString(encryptedData1);

                nvPairs.add(new BasicNameValuePair("msg1", Base64.getEncoder().encodeToString(encryptedData1)));
                nvPairs.add(new BasicNameValuePair("msg2",Base64.getEncoder().encodeToString(encryptedData2)));


                UrlEncodedFormEntity params = new UrlEncodedFormEntity(nvPairs);
                post.setEntity(params);
                response = client.execute(post);
                Log.i(TAG, "After client.execute()");
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Unsupported Encoding used");
            } catch (ClientProtocolException e) {
                Log.e(TAG, "Client Protocol Exception");
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            }catch (Exception e) {
                e.printStackTrace();
            }

            if (response != null) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(response.getEntity()
                                        .getContent()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        msg = sb.toString();
                    } catch (IOException e) {
                        Log.e(TAG, "IO Exception in reading from stream.");
                    }
                } else {
                    msg = "Status code other than HTTP 200 received";
                }
            } else {
                msg = "Response is null";
            }
            Log.i(TAG, "msg = " + msg);
            return msg;
        }
    }


    private class BankOu extends AsyncTask<Void, Void, String> {
        String msg = "";

        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            Toast.makeText(Data.this, "인출 되었습니다.", Toast.LENGTH_SHORT).show();

        }

        // 실제 전송하는 부분
        public String executeClient() {

            Log.i(TAG, "Execute executeClient()");
            HttpClient client = new DefaultHttpClient();

            // HttpPost post = new HttpPost("http://logindemo1.appspot.com/logindemo");
            // HttpPost post = new HttpPost("http://210.93.60.86/login");
            HttpPost post = new HttpPost("http://192.168.10.100/ou");

            HttpResponse response = null;

            // post 데이터 설정을 통한 매개 변수 전달
            String msg1 = editText1.getText().toString();
            String msg2 = editText2.getText().toString();
            List<NameValuePair> nvPairs = new ArrayList<NameValuePair>(2);
            try {
                Charset charset = Charset.forName("UTF-8");
                // 암호화
                SecretKeySpec sks = new SecretKeySpec(keyBytes, "AES");
                IvParameterSpec iv = new IvParameterSpec(ivBytes);
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
                cipher.init(Cipher.ENCRYPT_MODE, sks, iv);
                byte[] encryptedData1 = cipher.doFinal(msg1.getBytes(charset));
                byte[] encryptedData2= cipher.doFinal(msg2.getBytes(charset));
                // System.out.println("암호문: " + bytesToHex(encryptedData));
                //String mssg1= Base64.getEncoder().encodeToString(encryptedData1);

                nvPairs.add(new BasicNameValuePair("msg1", Base64.getEncoder().encodeToString(encryptedData1)));
                nvPairs.add(new BasicNameValuePair("msg2",Base64.getEncoder().encodeToString(encryptedData2)));


                UrlEncodedFormEntity params = new UrlEncodedFormEntity(nvPairs);
                post.setEntity(params);
                response = client.execute(post);
                Log.i(TAG, "After client.execute()");
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Unsupported Encoding used");
            } catch (ClientProtocolException e) {
                Log.e(TAG, "Client Protocol Exception");
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            }catch (Exception e) {
                e.printStackTrace();
            }

            if (response != null) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    try {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(response.getEntity()
                                        .getContent()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        msg = sb.toString();
                    } catch (IOException e) {
                        Log.e(TAG, "IO Exception in reading from stream.");
                    }
                } else {
                    msg = "Status code other than HTTP 200 received";
                }
            } else {
                msg = "Response is null";
            }
            Log.i(TAG, "msg = " + msg);
            return msg;
        }
    }


    //종료하는 부분
    private class Exitu extends AsyncTask<Void, Void, String> {
        String msg = "";
        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }
        protected void onPostExecute(String result) {
            Toast.makeText(Data.this, "종료 되었습니다.", Toast.LENGTH_SHORT).show();
            finish();
        }
        // 실제 전송하는 부분
        public String executeClient() {
            HttpClient client = new DefaultHttpClient();
            HttpPost post = new HttpPost("http://192.168.10.100/exit");
            try {
                client.execute(post);
            } catch (IOException e) {
                Log.e(TAG, "IOException in HttpPost");
            }
            return msg;
        }
    }



}
