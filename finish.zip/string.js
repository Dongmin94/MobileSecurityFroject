// 모듈을 추출합니다.
var fs = require('fs');
var ejs = require('ejs');
var mysql = require('mysql');
var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');
var crypto = require('crypto');


var algorithm = 'sha1'; //암호화
var pass = 'bbbb';  //PASSWORD
var message = 'sha1testing';

// 데이터베이스와 연결합니다.
var conn = mysql.createConnection({
  host     : '127.0.0.1',
  user     : 'root',
  password : '1234',
  database : 'mobile'
});

conn.connect();

//서버 생성
var app = express();
app.set('port', process.env.PORT || 3000);


var sql = 'SELECT * FROM bankinfo';



app.get('/', function(req,res){
    res.send('Root');
});

//알고리즘
var HmacGeneration = function() {
        var hmac = crypto.createHmac(algorithm, pass);
        hmac.update(message, 'ascii');
        hash = hmac.digest('hex');
        return hash;
};

// 미들웨어를 설정합니다.
//시용자 아이디와 비번 추출.
app.use(bodyParser.urlencoded({ extended:false}));


app.post('/login', function(request, response) {

    // 쿠키를 생성합니다.
    var username = request.body.username;
    var password = request.body.password;

    // 출력합니다.
    console.log('ID: ',username);
    console.log('PassWord: ', password);
     console.log('');
    // 로그인을 확인합니다.
    if(username == 'aaaa' && password == HmacGeneration()) { //수정한 부분
        // 로그인 성공
        response.send('<h1>로그인 성공</h1>');
        console.log('Login success!!');
    } else {
        // 로그인 실패
        response.send('<h1>Login failed!!</h1>');
        console.log('Login failed!!');
    }
});
//서버 종료
app.post('/exit', function(req, res){
        console.log('Exit');

    process.exit();
});

// 서버를 실행합니다.
app.listen(80, function() {
    console.log('server is running');
});

// 라우트를 수행합니다.
app.get('/my', function(request, response) {
    // 파일을 읽습니다.
    fs.readFile('testing.html', 'utf8', function(error, data) {
         // 데이터베이스 쿼리를 실행합니다.
        conn.query('SELECT * FROM bankinfo', function(error, results) {
             // 응답합니다.
            response.send(ejs.render(data, {
                data : results
            }));
        });
    });
});

var keyS = "MTIzNDU2Nzg5MDEy";
var ivS = "mTIzNDU2Nzg5MDEy";
function encrypt(data, data1, data2, keyS,ivS){
    var cipher = crypto.createCipheriv( "AES-128-CBC",keyS, ivS );
    var encryptedInput = cipher.update(data , "utf8", "base64" );
     encryptedInput+=cipher.update(', ' , "utf8", "base64" );
    encryptedInput+=cipher.update(data1 , "utf8", "base64" );
     encryptedInput+=cipher.update(', ' , "utf8", "base64" );
    encryptedInput+=cipher.update(data2, "utf8", "base64" );
    encryptedInput+=cipher.final( "base64" );
    return encryptedInput;
}


app.post('/ok', function(request, response) {

    // 쿠키를 생성합니다.
    var msg1 = request.body.msg1;
    var keyStr = "MTIzNDU2Nzg5MDEy";
var ivStr = "mTIzNDU2Nzg5MDEy";
var decipher = crypto.createDecipheriv( "AES-128-CBC",keyStr, ivStr );

    var decryptedInput = (
        decipher.update( msg1, "base64", "utf8" ) +
        decipher.final( "utf8" )
);

        console.log('banknum: ',msg1);
 console.log('');
         // 데이터베이스 쿼리를 실행합니다.
        conn.query('SELECT * FROM bankinfo WHERE banknum=?',[decryptedInput], function(error,user,results) {
             // 응답합니다.
            console.log('query (encrypt): ',encrypt(user[0].id.toString(),user[0].banknum.toString(),user[0].money.toString(),keyS,ivS));
            console.log('');
            response.send(encrypt(user[0].id.toString(),user[0].banknum.toString(),user[0].money.toString(),keyS,ivS));
            
        });
        
});




app.post('/mk', function(request, response) {

    // 쿠키를 생성합니다.
    var msg1 = request.body.msg1;
    var msg2 = request.body.msg2;
var keyStr = "MTIzNDU2Nzg5MDEy";
var ivStr = "mTIzNDU2Nzg5MDEy";
var decipher = crypto.createDecipheriv( "AES-128-CBC",keyStr, ivStr );
var keySt = "MTIzNDU2Nzg5MDEy";
var ivSt = "mTIzNDU2Nzg5MDEy";
var deciphe = crypto.createDecipheriv( "AES-128-CBC",keySt, ivSt );

    var decryptedInput1 = (
        decipher.update( msg1, "base64", "utf8" ) +
        decipher.final( "utf8" )
);
    var decryptedInput2 = (
        deciphe.update( msg2, "base64", "utf8" ) +
        deciphe.final( "utf8" )
);

    console.log('banknum: ',msg1);
        console.log('money: ', msg2);
 console.log('');

         // 데이터베이스 쿼리를 실행합니다.
        conn.query('INSERT INTO bankinfo (banknum,money)VALUES (?,?) ',[decryptedInput1,decryptedInput2], function(error, results) {
             // 응답합니다.
            response.redirect('/');
        });
});

app.post('/in', function(request, response) {

    // 쿠키를 생성합니다.
    var msg1 = request.body.msg1;
    var msg2 = request.body.msg2;
var keyStr = "MTIzNDU2Nzg5MDEy";
var ivStr = "mTIzNDU2Nzg5MDEy";
var decipher = crypto.createDecipheriv( "AES-128-CBC",keyStr, ivStr );
var keySt = "MTIzNDU2Nzg5MDEy";
var ivSt = "mTIzNDU2Nzg5MDEy";
var deciphe = crypto.createDecipheriv( "AES-128-CBC",keySt, ivSt );

    var decryptedInput1 = (
        decipher.update( msg1, "base64", "utf8" ) +
        decipher.final( "utf8" )
);
    var decryptedInput2 = (
        deciphe.update( msg2, "base64", "utf8" ) +
        deciphe.final( "utf8" )
);
    console.log('banknum: ',msg1);
        console.log('money: ', msg2);
     console.log('');
         // 데이터베이스 쿼리를 실행합니다.
        conn.query('UPDATE bankinfo SET money=money+? WHERE banknum=?',[decryptedInput2,decryptedInput1], function(error, results) {
             // 응답합니다.
            response.redirect('/');
        });
});

app.post('/ou', function(request, response) {

    // 쿠키를 생성합니다.
    var msg1 = request.body.msg1;
    var msg2 = request.body.msg2;
var keyStr = "MTIzNDU2Nzg5MDEy";
var ivStr = "mTIzNDU2Nzg5MDEy";
var decipher = crypto.createDecipheriv( "AES-128-CBC",keyStr, ivStr );
var keySt = "MTIzNDU2Nzg5MDEy";
var ivSt = "mTIzNDU2Nzg5MDEy";
var deciphe = crypto.createDecipheriv( "AES-128-CBC",keySt, ivSt );

    var decryptedInput1 = (
        decipher.update( msg1, "base64", "utf8" ) +
        decipher.final( "utf8" )
);
    var decryptedInput2 = (
        deciphe.update( msg2, "base64", "utf8" ) +
        deciphe.final( "utf8" )
);    console.log('banknum: ',msg1,'money: ', msg2);
console.log('banknum: ',msg1);
        console.log('money: ', msg2);
        console.log('');

         // 데이터베이스 쿼리를 실행합니다.
        conn.query('UPDATE bankinfo SET money=money-? WHERE banknum=?',[decryptedInput2,decryptedInput1], function(error, results) {
             // 응답합니다.
            response.redirect('/');
    });
});

/*

// 서버를 생성합니다.
var app = express();

*/




